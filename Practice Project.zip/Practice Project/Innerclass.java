package assistedproject;

public class Innerclass {
	public static void main(String[] args) {
		class OuterClass {
			  int x = 20;

			  class InnerClass {
			    int y = 5;
			  }
			}
	 				
   OuterClass myOuter = new OuterClass();
   OuterClass.InnerClass myInner = myOuter.new InnerClass();
   System.out.println(myInner.y + myOuter.x);

}

}




