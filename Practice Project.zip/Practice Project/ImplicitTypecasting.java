package assistedproject;

public class ImplicitTypecasting {
	public static void main(String[] args) {
		//Implicit Type Casting
		int a = 4;
		long b = a;
		float c = b;
		System.out.println("Implicit Type Casting");
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		
		
		//Explicit Type Casting
		int P = 65;
		char Q = (char) P;
		long l = (long) Q;
		int i = (int) l;
		System.out.println("explicit Type Casting");
		System.out.println(Q);
		System.out.println(l);
		System.out.println(i);
	}
}
		
