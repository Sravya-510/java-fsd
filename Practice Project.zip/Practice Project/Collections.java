package assistedproject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Vector;


public class Collections {
	public static void main(String[] args) {
		ArrayList<String> list=new ArrayList<String>();
			list.add("Sravya");  //Adding object in arraylist
			list.add("Bhavya");
			Iterator<String> itr=list.iterator();
			while(itr.hasNext()) {
				System.out.println(itr.next());
		   
	  LinkedList<String> ls=new LinkedList<String>();
		   ls.add("Kavya");       //Adding object in LinkedLIST
		   ls.add("Jahnavi");
		   Iterator<String>krs=ls.iterator();
		   while(krs.hasNext()) {
		   System.out.println(krs.next());
	   
	   Vector<String> V=new Vector<String>();
	   	   V.add("Sudarsini");      //Adding object in Vector
		   V.add("Sindhu");
		   Iterator<String>Q=V.iterator();
		   while(Q.hasNext()) {
		   System.out.println(Q.next());
			
     	 }
	
     	}

	   }

	}

}



