package assistedproject;
import java.util.Scanner;
public class CallingMethods {
		int sum(int a,int b){
			int x= a;
			int y= b;
			int z= x+y ;
			System.out.println(z);
			return z;
		}

	public static void main(String[] args) {
		Scanner S = new Scanner(System.in);
		System.out.println("Enter a value: ");
		int a = S.nextInt();
		System.out.println("Enter b value: ");
		int b = S.nextInt();
		CallingMethods CM = new CallingMethods();
		System.out.println("the value is ");
		CM.sum(a,b);

		
	}

}

