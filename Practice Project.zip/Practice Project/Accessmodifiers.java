package assistedproject;
class one{
	// example for private
	private int p=10;
	// example for protected
	protected void display(){
		System.out.println(" this is protected modifier");
	}
	//example for public
	public void demo(){
		System.out.println("the value is "+ p);
	}
	//example for default
	void disk() 
    { 
        System.out.println("this is default modifier"); 
    } 
}


public class Accessmodifiers {

	public static void main(String[] args) {
		one i = new one();
		//System.out.println("the value a is "+ p);
		/*here the variable 
		 p has been declared private so it can't be accessed in the class
		 */
		i.display();
		i.demo();
		i.disk();

	}

}



