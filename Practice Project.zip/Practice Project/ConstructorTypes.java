package assistedproject;

public class ConstructorTypes {
	//1) Default Constructor 2) Parameterised Constructor
			public static void main(String[] args) {
			// Example for Default Constructor 
				display D = new display();
			}
		}
			class display{			
				public display() {
				System.out.println("Executing Constructor code");
			 }				
		   // 2)Example for parameterized constructor		
				Para P = new Para(35);
				class Para{
					public Para(int i) {
	System.out.println("The value of the parameterised constructor is " +i);
					}	
				}
			}
